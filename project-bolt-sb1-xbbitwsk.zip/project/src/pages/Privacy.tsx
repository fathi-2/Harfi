import React from 'react';
import { ShieldIcon } from 'lucide-react';
import PageHeader from '../components/shared/PageHeader';

export default function Privacy() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <PageHeader title="Privacy Policy" Icon={ShieldIcon} />
      <div className="bg-white rounded-lg shadow-md p-6 prose max-w-none">
        <h2>Introduction</h2>
        <p>
          At SportsPulse, we take your privacy seriously. This policy describes how we collect,
          use, and protect your personal information.
        </p>
        
        <h2>Information We Collect</h2>
        <p>
          We collect information that you provide directly to us, including:
        </p>
        <ul>
          <li>Name and contact information</li>
          <li>Account credentials</li>
          <li>Communication preferences</li>
        </ul>
      </div>
    </div>
  );
}