import React from 'react';
import { NewspaperIcon } from 'lucide-react';

export default function News() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-2 mb-6">
        <NewspaperIcon className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Latest News</h1>
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3, 4, 5, 6].map((item) => (
          <article key={item} className="bg-white rounded-lg shadow-md overflow-hidden">
            <img
              src={`https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&h=400&fit=crop`}
              alt="Sports"
              className="w-full h-48 object-cover"
            />
            <div className="p-4">
              <span className="text-sm text-blue-600 font-semibold">FOOTBALL</span>
              <h2 className="text-xl font-bold mt-2">Major League Final Approaches</h2>
              <p className="text-gray-600 mt-2">
                Latest updates on the upcoming championship match and team preparations...
              </p>
              <button 
                onClick={() => console.log('Read more clicked')}
                className="mt-4 text-blue-600 font-semibold hover:text-blue-800"
              >
                Read more →
              </button>
            </div>
          </article>
        ))}
      </div>
    </div>
  );
}