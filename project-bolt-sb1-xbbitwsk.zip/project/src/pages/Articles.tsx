import React from 'react';
import { BookOpenIcon } from 'lucide-react';
import AdBanner from '../components/shared/AdBanner';

export default function Articles() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-2 mb-6">
        <BookOpenIcon className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Featured Articles</h1>
      </div>
      
      <div className="flex flex-col lg:flex-row gap-8">
        <div className="flex-1 space-y-8">
          {[1, 2, 3].map((item) => (
            <article key={item} className="bg-white rounded-lg shadow-md p-6">
              <div className="flex flex-col md:flex-row gap-6">
                <img
                  src={`https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=400`}
                  alt="Sports"
                  className="w-full md:w-64 h-48 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <span className="text-sm text-blue-600 font-semibold">ANALYSIS</span>
                  <h2 className="text-2xl font-bold mt-2">The Evolution of Modern Football</h2>
                  <p className="text-gray-600 mt-2 line-clamp-3">
                    An in-depth look at how the beautiful game has changed over the decades...
                  </p>
                  <button 
                    onClick={() => console.log('Read full article clicked')}
                    className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    Read full article
                  </button>
                </div>
              </div>
              {item === 2 && (
                <AdBanner slot="in-article" className="mt-6" />
              )}
            </article>
          ))}
        </div>
        
        <div className="lg:w-80 space-y-6">
          <AdBanner slot="sidebar" className="sticky top-6" />
        </div>
      </div>
    </div>
  );
}