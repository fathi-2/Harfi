import React from 'react';
import { TrophyIcon } from 'lucide-react';

export default function Results() {
  const leagues = ['Premier League', 'La Liga', 'Serie A', 'Bundesliga'];
  
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex items-center gap-2 mb-6">
        <TrophyIcon className="h-8 w-8 text-blue-600" />
        <h1 className="text-3xl font-bold">Match Results</h1>
      </div>
      
      <div className="space-y-8">
        {leagues.map((league) => (
          <section key={league}>
            <h2 className="text-xl font-semibold mb-4">{league}</h2>
            <div className="space-y-4">
              {[1, 2, 3].map((match) => (
                <div key={match} className="bg-white rounded-lg shadow-md p-4">
                  <div className="flex justify-between items-center">
                    <div className="flex-1">
                      <span className="font-semibold">Team A</span>
                    </div>
                    <div className="px-4 py-2 bg-gray-100 rounded-lg font-bold">
                      2 - 1
                    </div>
                    <div className="flex-1 text-right">
                      <span className="font-semibold">Team B</span>
                    </div>
                  </div>
                  <div className="text-sm text-gray-500 mt-2 text-center">
                    Final • March 10, 2024
                  </div>
                </div>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}