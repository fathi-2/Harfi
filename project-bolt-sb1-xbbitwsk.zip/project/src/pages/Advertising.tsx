import React from 'react';
import { LayoutTemplate } from 'lucide-react';
import PageHeader from '../components/shared/PageHeader';

export default function Advertising() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <PageHeader title="Advertising" Icon={LayoutTemplate} />
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="prose max-w-none">
          <h2>Advertise with Us</h2>
          <p>
            Reach millions of sports fans through our various advertising options.
          </p>
          <h3>Available Positions</h3>
          <ul>
            <li>Homepage Banner</li>
            <li>Article Sidebar</li>
            <li>Newsletter Sponsorship</li>
          </ul>
          <div className="mt-6">
            <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Download Media Kit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}