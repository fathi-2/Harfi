import React from 'react';
import { InfoIcon } from 'lucide-react';
import PageHeader from '../components/shared/PageHeader';

export default function About() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <PageHeader title="About Us" Icon={InfoIcon} />
      <div className="bg-white rounded-lg shadow-md p-6">
        <div className="prose max-w-none">
          <p className="lead">
            SportsPulse is your premier destination for sports news, results, and in-depth analysis.
          </p>
          <h2>Our Mission</h2>
          <p>
            We strive to deliver accurate, timely, and engaging sports content to fans worldwide.
          </p>
          <h2>Our Team</h2>
          <p>
            Our team consists of passionate sports journalists and industry experts dedicated to
            bringing you the best coverage.
          </p>
        </div>
      </div>
    </div>
  );
}