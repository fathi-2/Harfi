import React from 'react';
import { BriefcaseIcon } from 'lucide-react';
import PageHeader from '../components/shared/PageHeader';

export default function Jobs() {
  const jobs = [
    {
      title: 'Sports Journalist',
      location: 'Remote',
      type: 'Full-time',
      description: 'Looking for an experienced sports journalist to cover major sporting events.'
    },
    {
      title: 'Content Editor',
      location: 'New York',
      type: 'Full-time',
      description: 'Seeking a detail-oriented content editor for our digital sports platform.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <PageHeader title="Career Opportunities" Icon={BriefcaseIcon} />
      <div className="space-y-6">
        {jobs.map((job, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold text-gray-900">{job.title}</h2>
            <div className="flex gap-4 mt-2">
              <span className="text-sm text-gray-500">{job.location}</span>
              <span className="text-sm text-gray-500">{job.type}</span>
            </div>
            <p className="mt-4 text-gray-600">{job.description}</p>
            <button className="mt-4 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
              Apply Now
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}