import React from 'react';
import FeaturedNews from '../components/home/FeaturedNews';
import NewsletterSignup from '../components/home/NewsletterSignup';
import LatestResults from '../components/home/LatestResults';
import AdBanner from '../components/shared/AdBanner';

export default function Home() {
  return (
    <div className="space-y-8">
      <AdBanner slot="header" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" />
      <FeaturedNews />
      <LatestResults />
      <AdBanner slot="footer" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" />
      <NewsletterSignup />
    </div>
  );
}