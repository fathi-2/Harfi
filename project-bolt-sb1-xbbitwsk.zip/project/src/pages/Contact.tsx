import React from 'react';
import { MailIcon } from 'lucide-react';
import PageHeader from '../components/shared/PageHeader';
import ContactForm from '../components/contact/ContactForm';

export default function Contact() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <PageHeader title="Contact Us" Icon={MailIcon} />
      <div className="bg-white rounded-lg shadow-md p-6">
        <ContactForm />
      </div>
    </div>
  );
}