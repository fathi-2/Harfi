import React from 'react';
import { LucideIcon } from 'lucide-react';

interface PageHeaderProps {
  title: string;
  Icon: LucideIcon;
}

export default function PageHeader({ title, Icon }: PageHeaderProps) {
  return (
    <div className="flex items-center gap-2 mb-6">
      <Icon className="h-8 w-8 text-blue-600" />
      <h1 className="text-3xl font-bold">{title}</h1>
    </div>
  );
}