import React from 'react';

interface AdBannerProps {
  slot: 'header' | 'sidebar' | 'footer' | 'in-article';
  className?: string;
}

export default function AdBanner({ slot, className = '' }: AdBannerProps) {
  return (
    <div 
      className={`ad-container ${className} min-h-[90px] bg-gray-50 flex items-center justify-center`}
      data-ad-slot={slot}
    >
      {/* Ad script will populate this container */}
      <div id={`ad-${slot}`} className="text-center" />
    </div>
  );
}