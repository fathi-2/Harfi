import React, { useState } from 'react';
import { Menu, Search, Bell, User } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <header className="bg-white shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <button 
              className="p-2 rounded-md text-gray-600 hover:text-gray-900 focus:outline-none md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
            <Link to="/" className="ml-4 font-bold text-xl text-blue-600">SportsPulse</Link>
          </div>
          
          <nav className={`
            ${isMenuOpen ? 'block' : 'hidden'} 
            md:flex md:space-x-8 
            absolute md:relative 
            top-16 md:top-0 
            left-0 md:left-auto 
            w-full md:w-auto 
            bg-white md:bg-transparent 
            shadow-md md:shadow-none 
            z-50 md:z-auto
            p-4 md:p-0
          `}>
            <Link to="/news" className="block md:inline-block py-2 text-gray-600 hover:text-gray-900">News</Link>
            <Link to="/articles" className="block md:inline-block py-2 text-gray-600 hover:text-gray-900">Articles</Link>
            <Link to="/results" className="block md:inline-block py-2 text-gray-600 hover:text-gray-900">Results</Link>
            <Link to="/jobs" className="block md:inline-block py-2 text-gray-600 hover:text-gray-900">Jobs</Link>
          </nav>

          <div className="flex items-center space-x-4">
            <button 
              className="p-2 rounded-md text-gray-600 hover:text-gray-900"
              onClick={() => navigate('/search')}
            >
              <Search className="h-5 w-5" />
            </button>
            <button className="p-2 rounded-md text-gray-600 hover:text-gray-900">
              <Bell className="h-5 w-5" />
            </button>
            <button className="p-2 rounded-md text-gray-600 hover:text-gray-900">
              <User className="h-5 w-5" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}