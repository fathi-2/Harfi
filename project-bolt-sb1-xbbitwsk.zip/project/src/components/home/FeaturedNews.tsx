import React from 'react';
import { Clock } from 'lucide-react';

export default function FeaturedNews() {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="relative h-96 rounded-xl overflow-hidden">
          <img
            src="https://images.unsplash.com/photo-1461896836934-ffe607ba8211?ixlib=rb-4.0.3"
            alt="Featured sports"
            className="w-full h-full object-cover"
          />
          <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-6">
            <span className="text-sm text-blue-400">FOOTBALL</span>
            <h2 className="text-2xl font-bold text-white mt-2">
              Champions League Final Set for Epic Showdown
            </h2>
            <div className="flex items-center mt-2 text-gray-300">
              <Clock className="h-4 w-4 mr-2" />
              <span className="text-sm">2 hours ago</span>
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-xl font-bold text-gray-900">Latest Updates</h3>
          {[1, 2, 3].map((i) => (
            <div key={i} className="bg-white rounded-lg shadow p-4">
              <span className="text-sm text-blue-600">BASKETBALL</span>
              <h4 className="font-semibold mt-1">NBA Playoffs: Eastern Conference Finals Preview</h4>
              <p className="text-gray-600 text-sm mt-2">
                Complete analysis of the upcoming conference finals matchup...
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}