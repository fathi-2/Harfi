import React from 'react';
import { Trophy } from 'lucide-react';

export default function LatestResults() {
  const matches = [
    {
      league: 'Premier League',
      homeTeam: 'Arsenal',
      awayTeam: 'Chelsea',
      score: '2 - 1',
      date: 'March 15, 2024'
    },
    {
      league: 'La Liga',
      homeTeam: 'Barcelona',
      awayTeam: 'Real Madrid',
      score: '3 - 3',
      date: 'March 14, 2024'
    }
  ];

  return (
    <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center gap-2 mb-6">
        <Trophy className="h-6 w-6 text-blue-600" />
        <h2 className="text-2xl font-bold">Latest Results</h2>
      </div>
      <div className="grid gap-4">
        {matches.map((match, index) => (
          <div key={index} className="bg-white rounded-lg shadow-md p-4">
            <div className="text-sm text-blue-600 mb-2">{match.league}</div>
            <div className="flex justify-between items-center">
              <span className="font-semibold">{match.homeTeam}</span>
              <span className="px-4 py-2 bg-gray-100 rounded-lg font-bold">
                {match.score}
              </span>
              <span className="font-semibold">{match.awayTeam}</span>
            </div>
            <div className="text-sm text-gray-500 mt-2 text-center">
              {match.date}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}