import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Home from '../pages/Home';
import News from '../pages/News';
import Articles from '../pages/Articles';
import Results from '../pages/Results';
import Contact from '../pages/Contact';
import Privacy from '../pages/Privacy';
import About from '../pages/About';
import Jobs from '../pages/Jobs';
import Advertising from '../pages/Advertising';

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/news" element={<News />} />
      <Route path="/articles" element={<Articles />} />
      <Route path="/results" element={<Results />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/privacy" element={<Privacy />} />
      <Route path="/about" element={<About />} />
      <Route path="/jobs" element={<Jobs />} />
      <Route path="/advertising" element={<Advertising />} />
    </Routes>
  );
}